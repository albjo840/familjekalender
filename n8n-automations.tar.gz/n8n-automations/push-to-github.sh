#!/bin/bash

# Interaktivt skript för att pusha till GitHub
# Användning: ./push-to-github.sh

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}   Push n8n-automations till GitHub${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""

# Kontrollera att vi är i rätt katalog
if [ ! -f "create-project.sh" ]; then
    echo -e "${RED}❌ Fel: Kör skriptet från n8n-automations mappen${NC}"
    exit 1
fi

# Kontrollera git status
echo -e "${YELLOW}📊 Kontrollerar git status...${NC}"
git status

echo ""
echo -e "${BLUE}══════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}⚠️  VIKTIGT: GitHub Personal Access Token (PAT)${NC}"
echo -e "${BLUE}══════════════════════════════════════════════════════${NC}"
echo ""
echo "GitHub kräver en Personal Access Token (PAT) istället för lösenord."
echo ""
echo "Om du inte har en PAT:"
echo "1. Gå till: https://github.com/settings/tokens"
echo "2. Klicka 'Generate new token (classic)'"
echo "3. Välj scope: 'repo'"
echo "4. Kopiera token (visas bara en gång!)"
echo ""
read -p "Har du en PAT redo? (ja/nej): " has_token

if [ "$has_token" != "ja" ]; then
    echo -e "${YELLOW}Skapa en PAT först, sedan kör skriptet igen.${NC}"
    exit 0
fi

echo ""
echo -e "${BLUE}📝 GitHub Repository Information${NC}"
echo ""

# Användarnamn
read -p "GitHub användarnamn [albjo840]: " github_user
github_user=${github_user:-albjo840}

# Repo namn
read -p "Repository namn [n8n-automations]: " repo_name
repo_name=${repo_name:-n8n-automations}

REPO_URL="https://github.com/${github_user}/${repo_name}.git"

echo ""
echo -e "${YELLOW}Repository URL: ${REPO_URL}${NC}"
echo ""

# Kontrollera om remote redan finns
if git remote | grep -q "^origin$"; then
    echo -e "${YELLOW}⚠️  Remote 'origin' finns redan${NC}"
    read -p "Vill du uppdatera den? (ja/nej): " update_remote

    if [ "$update_remote" = "ja" ]; then
        git remote remove origin
        git remote add origin "$REPO_URL"
        echo -e "${GREEN}✅ Remote uppdaterad${NC}"
    fi
else
    git remote add origin "$REPO_URL"
    echo -e "${GREEN}✅ Remote tillagd${NC}"
fi

# Byt till main branch
echo ""
echo -e "${YELLOW}🔄 Byter till main branch...${NC}"
git branch -M main

# Pusha
echo ""
echo -e "${YELLOW}🚀 Pushar till GitHub...${NC}"
echo ""
echo -e "${BLUE}När det frågar efter lösenord:${NC}"
echo -e "  Användarnamn: ${YELLOW}${github_user}${NC}"
echo -e "  Lösenord: ${YELLOW}Klistra in din PAT (inte vanligt lösenord!)${NC}"
echo ""

read -p "Tryck ENTER för att fortsätta..."

if git push -u origin main; then
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}✅ Push lyckades!${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${BLUE}📍 Ditt repository:${NC}"
    echo -e "   https://github.com/${github_user}/${repo_name}"
    echo ""
    echo -e "${BLUE}📝 Nästa steg (på hemservern):${NC}"
    echo -e "   git clone https://github.com/${github_user}/${repo_name}.git"
    echo -e "   cd ${repo_name}"
    echo -e "   ./deploy-to-server.sh"
    echo ""
else
    echo ""
    echo -e "${RED}═══════════════════════════════════════════════════════${NC}"
    echo -e "${RED}❌ Push misslyckades${NC}"
    echo -e "${RED}═══════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${YELLOW}Vanliga problem:${NC}"
    echo ""
    echo -e "${BLUE}1. Authentication failed:${NC}"
    echo "   - Använd PAT, inte vanligt lösenord"
    echo "   - Skapa ny PAT: https://github.com/settings/tokens"
    echo ""
    echo -e "${BLUE}2. Repository not found:${NC}"
    echo "   - Skapa repot först: https://github.com/new"
    echo "   - Namn: ${repo_name}"
    echo "   - Public"
    echo "   - KRYSSA INTE i 'Add README'"
    echo ""
    echo -e "${BLUE}3. Permission denied:${NC}"
    echo "   - Kontrollera att PAT har 'repo' scope"
    echo ""
fi
