# Push till GitHub - Snabbguide

## Steg 1: Skapa GitHub Repository

1. Gå till https://github.com/new
2. Fyll i:
   - **Repository name**: `n8n-automations`
   - **Description**: "n8n automation framework med säljrobot för lead-generering"
   - **Public** ✅ (för alla GitHub-funktioner)
   - **VIKTIGT**: Kryssa INTE i "Add README" (vi har redan en)
3. Klicka "Create repository"

## Steg 2: Pusha från jobbet (enklaste)

GitHub kommer visa dig en sida med instruktioner. Kör detta:

```bash
cd /home/user/n8n-automations

# Lägg till remote
git remote add origin https://github.com/albjo840/n8n-automations.git

# Byt branch-namn till main (GitHub standard)
git branch -M main

# Pusha!
git push -u origin main
```

**När det frågar efter lösenord:**
- Användarnamn: `albjo840`
- Lösenord: **Använd INTE ditt vanliga lösenord!**
  - GitHub kräver "Personal Access Token" (PAT)
  - Se Steg 3 nedan

## Steg 3: Skapa Personal Access Token (PAT)

GitHub accepterar inte vanliga lösenord längre. Du behöver en PAT:

1. Gå till https://github.com/settings/tokens
2. Klicka "Generate new token" → "Generate new token (classic)"
3. Fyll i:
   - **Note**: "n8n-automations push"
   - **Expiration**: 90 days (eller längre)
   - **Scopes**: Kryssa i `repo` (ger full repo-åtkomst)
4. Klicka "Generate token"
5. **KOPIERA TOKEN NU!** (visas bara en gång)

Exempel token: `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

## Steg 4: Pusha med PAT

```bash
cd /home/user/n8n-automations
git push -u origin main
```

När det frågar:
- **Username**: `albjo840`
- **Password**: Klistra in din PAT (inte vanligt lösenord!)

## Alternativ: SSH-nycklar (säkrare, men mer setup)

Om du föredrar SSH:

```bash
# Generera SSH-nyckel
ssh-keygen -t ed25519 -C "your_email@example.com"

# Visa publik nyckel
cat ~/.ssh/id_ed25519.pub

# Kopiera output och lägg till på GitHub:
# https://github.com/settings/ssh/new

# Använd SSH remote istället
git remote set-url origin git@github.com:albjo840/n8n-automations.git
git push -u origin main
```

## Steg 5: Verifiera

Efter push, gå till: https://github.com/albjo840/n8n-automations

Du ska se:
- ✅ README.md med projektbeskrivning
- ✅ saljrobot/ mapp
- ✅ _template/ mapp
- ✅ Alla guider och skript
- ✅ 5 commits i historiken

## Göm känslig företagsinformation

Du kan göra repot publikt MEN dölja vissa filer:

**Option 1: Skapa .env.example istället för .env**
- Redan gjort! ✅
- `.env` filer är gitignorerade
- Bara `.env.example` finns i repo (utan riktiga lösenord)

**Option 2: Lägg till .gitignore-regler**

Om du vill dölja mer, lägg till i `.gitignore`:
```bash
# Företagsinformation
**/målgrupper.txt
**/kunddata/
**/leads/
```

**Option 3: Branch för intern info**

```bash
# Skapa privat branch för företagsinfo
git checkout -b private-config
# Lägg till känslig info här
git push origin private-config

# Håll main branch ren och publik
git checkout main
```

## Snabb-push skript

Eller kör detta skript:

```bash
cd /home/user/n8n-automations
./push-to-github.sh
```

## Felsökning

### "remote origin already exists"
```bash
git remote remove origin
git remote add origin https://github.com/albjo840/n8n-automations.git
```

### "Authentication failed"
- Kontrollera att du använder PAT, inte vanligt lösenord
- Generera ny PAT om den gamla inte fungerar

### "Repository not found"
- Kontrollera att du skapat repot på GitHub först
- Kolla att URL:en stämmer: `https://github.com/albjo840/n8n-automations.git`

## Nästa steg efter push

1. ✅ Klona på hemservern: `git clone https://github.com/albjo840/n8n-automations.git`
2. ✅ Kör deploy-skript: `cd n8n-automations && ./deploy-to-server.sh`
3. ✅ Öppna n8n: `http://100.81.105.182:5679`

Lycka till! 🚀
