# Setup Guide - n8n på din Hemserver

Guide för att installera och konfigurera n8n-automationsprojekt på din hemserver.

## Server-information

```
DuckDNS-adress:     taborsen.duckdns.org
Publik IP (IPv6):   2a00:1598:c005:9e::1:3194
Lokal IP (hemma):   100.81.105.182 (Tailscale)

WireGuard-port:     51820 (UDP)
SSH-port:           22 (TCP)

VPN-IP (hemserver): 10.0.0.1
VPN-IP (klient):    10.0.0.2
```

## Del 1: Förberedelser (på hemservern)

### 1.1 Installera Docker

```bash
# SSH in till hemservern
ssh user@taborsen.duckdns.org
# eller via Tailscale
ssh user@100.81.105.182

# Installera Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Lägg till din användare i docker-gruppen
sudo usermod -aG docker $USER

# Logga ut och in igen, eller kör:
newgrp docker

# Verifiera installation
docker --version
docker compose version
```

### 1.2 Installera Git (om inte redan installerat)

```bash
sudo apt update
sudo apt install -y git
```

### 1.3 Skapa projektmapp

```bash
mkdir -p ~/projects
cd ~/projects
```

## Del 2: Klona n8n-automations projektet

### 2.1 Från GitHub (när du pushat)

```bash
cd ~/projects
git clone https://github.com/ditt-användarnamn/n8n-automations.git
cd n8n-automations
```

### 2.2 Eller kopiera direkt från jobbdatorn

**På jobbdatorn:**
```bash
cd /home/user/n8n-automations
tar -czf n8n-automations.tar.gz .
scp n8n-automations.tar.gz user@100.81.105.182:~/projects/
```

**På hemservern:**
```bash
cd ~/projects
tar -xzf n8n-automations.tar.gz
mv n8n-automations.tar.gz n8n-automations/
cd n8n-automations
```

## Del 3: Starta Säljroboten

### 3.1 Grundläggande start (lokal åtkomst)

```bash
cd ~/projects/n8n-automations/saljrobot

# Granska konfigurationen
cat .env

# Starta n8n
docker compose up -d

# Följ loggar
docker compose logs -f
```

**Åtkomst:**
- Lokalt på servern: `http://localhost:5679`
- Via Tailscale: `http://100.81.105.182:5679`
- Via WireGuard VPN: `http://10.0.0.1:5679`

**Login:**
- Användarnamn: `admin`
- Lösenord: Se i `.env`-filen

### 3.2 Verifiera att det fungerar

```bash
# Kontrollera status
docker compose ps

# Testa åtkomst
curl http://localhost:5679/healthz

# Visa loggar
docker compose logs -f n8n
```

## Del 4: Åtkomst från jobbet

### Option A: Via Tailscale (Enklast & Säkrast) ⭐

**Från jobbdatorn:**
```bash
# Anslut via Tailscale
# Öppna webbläsare: http://100.81.105.182:5679
```

Fördelar:
- ✅ Krypterad förbindelse
- ✅ Ingen portforward behövs
- ✅ Fungerar överallt
- ✅ Automatisk autentisering

### Option B: Via WireGuard VPN

**På jobbdatorn:**
```bash
# Anslut WireGuard VPN
sudo wg-quick up wg0

# Öppna webbläsare: http://10.0.0.1:5679
```

### Option C: Via DuckDNS (Extern åtkomst)

**VARNING:** Kräver port forwarding och SSL-certifikat!

Se "Del 5: Exponera till Internet" nedan.

## Del 5: Exponera till Internet (Optional)

### 5.1 Med Nginx Reverse Proxy + Let's Encrypt

**Installera Nginx:**
```bash
sudo apt install -y nginx certbot python3-certbot-nginx
```

**Konfigurera Nginx:**
```bash
sudo nano /etc/nginx/sites-available/n8n-saljrobot
```

Innehåll:
```nginx
server {
    listen 80;
    server_name saljrobot.taborsen.duckdns.org;

    location / {
        proxy_pass http://localhost:5679;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;

        # WebSocket support
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Aktivera site:**
```bash
sudo ln -s /etc/nginx/sites-available/n8n-saljrobot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

**Installera SSL-certifikat:**
```bash
sudo certbot --nginx -d saljrobot.taborsen.duckdns.org
```

**Uppdatera .env:**
```bash
cd ~/projects/n8n-automations/saljrobot
nano .env
```

Ändra:
```env
N8N_HOST=saljrobot.taborsen.duckdns.org
N8N_PROTOCOL=https
WEBHOOK_URL=https://saljrobot.taborsen.duckdns.org/
```

**Starta om n8n:**
```bash
docker compose restart
```

**Port forwarding (på din router):**
- Port 80 (HTTP) → 100.81.105.182:80
- Port 443 (HTTPS) → 100.81.105.182:443

### 5.2 Med Cloudflare Tunnel (Ingen port forwarding)

**Enklare alternativ utan port forwarding:**

```bash
# Installera cloudflared
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb

# Logga in
cloudflared tunnel login

# Skapa tunnel
cloudflared tunnel create saljrobot

# Konfigurera tunnel
nano ~/.cloudflared/config.yml
```

Innehåll:
```yaml
tunnel: <TUNNEL-ID>
credentials-file: /home/user/.cloudflared/<TUNNEL-ID>.json

ingress:
  - hostname: saljrobot.taborsen.duckdns.org
    service: http://localhost:5679
  - service: http_status:404
```

**Starta tunnel:**
```bash
cloudflared tunnel run saljrobot
```

## Del 6: Automatisk start vid omstart

### 6.1 Docker Compose (redan konfigurerat)

```yaml
# I docker-compose.yml finns redan:
restart: unless-stopped
```

Detta gör att n8n startar automatiskt vid server-omstart.

### 6.2 Verifiera auto-restart

```bash
# Starta om servern
sudo reboot

# Efter omstart, kontrollera
docker ps
```

## Del 7: Hantera flera n8n-instanser

### 7.1 Skapa nya projekt

```bash
cd ~/projects/n8n-automations

# Skapa nytt projekt
./create-project.sh telegram-bot 5680

# Starta
cd telegram-bot
docker compose up -d
```

## Del 8: Backup och underhåll

### 8.1 Automatiska backups

**Skapa cron-jobb:**
```bash
crontab -e
```

Lägg till:
```cron
# Backup säljrobot dagligen kl 02:00
0 2 * * * cd /home/user/projects/n8n-automations/saljrobot && ./scripts/backup.sh

# Lägg till fler projekt här om du vill
# 0 2 * * * cd /home/user/projects/n8n-automations/ditt-projekt && ./scripts/backup.sh
```

### 8.2 Manuell backup

```bash
cd ~/projects/n8n-automations/saljrobot
./scripts/backup.sh
```

### 8.3 Synka backups till annan plats

**Till NAS eller cloud:**
```bash
# Exempel: Rclone till Google Drive
rclone sync ~/projects/n8n-automations/saljrobot/backups gdrive:n8n-backups/saljrobot
```

## Del 9: Säkerhet

### 9.1 Firewall-regler

**Med UFW:**
```bash
sudo apt install -y ufw

# Tillåt SSH
sudo ufw allow 22/tcp

# Tillåt WireGuard
sudo ufw allow 51820/udp

# Tillåt HTTP/HTTPS (endast om du exponerar till internet)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Aktivera firewall
sudo ufw enable
```

### 9.2 Ändra lösenord

```bash
cd ~/projects/n8n-automations/saljrobot
nano .env
```

Ändra:
```env
N8N_BASIC_AUTH_PASSWORD=ditt-nya-starka-lösenord
```

```bash
docker compose restart
```

### 9.3 Begränsa åtkomst

**Endast via Tailscale/WireGuard:**

I `docker-compose.yml`, ändra:
```yaml
ports:
  - "127.0.0.1:5679:5678"  # Endast lokal åtkomst
```

Då kan du bara nå n8n via VPN.

## Del 10: Felsökning

### Problem: Container startar inte

```bash
# Kontrollera loggar
docker compose logs n8n

# Kontrollera status
docker compose ps

# Starta om
docker compose restart

# Full omstart
docker compose down
docker compose up -d
```

### Problem: Kan inte nå från jobbet

```bash
# Testa från hemservern
curl http://localhost:5679/healthz

# Testa via Tailscale IP
curl http://100.81.105.182:5679/healthz

# Kontrollera firewall
sudo ufw status
```

### Problem: Port redan används

```bash
# Se vad som använder porten
sudo lsof -i :5679

# Eller
sudo netstat -tlnp | grep 5679
```

### Problem: Docker tar mycket disk

```bash
# Rensa gamla images och containers
docker system prune -a

# Se disk-användning
docker system df
```

## Del 11: Övervaka n8n

### 11.1 Enkel monitoring

```bash
# Skapa monitoring-skript
cat > ~/monitor-n8n.sh << 'EOF'
#!/bin/bash
cd ~/projects/n8n-automations/saljrobot
if ! docker compose ps | grep -q "Up"; then
    echo "n8n är nere! Startar om..."
    docker compose restart
    # Skicka notifikation (optional)
    # curl -X POST "https://api.telegram.org/bot<token>/sendMessage" \
    #   -d "chat_id=<id>&text=n8n säljrobot startades om"
fi
EOF

chmod +x ~/monitor-n8n.sh
```

**Lägg till i cron:**
```bash
crontab -e
```

```cron
# Kolla n8n var 5:e minut
*/5 * * * * /home/user/monitor-n8n.sh
```

### 11.2 Med Portainer (Web UI för Docker)

```bash
docker volume create portainer_data
docker run -d \
  -p 9000:9000 \
  --name=portainer \
  --restart=always \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v portainer_data:/data \
  portainer/portainer-ce:latest
```

Åtkomst: `http://100.81.105.182:9000`

## Del 12: Snabbkommando-cheatsheet

```bash
# Starta säljrobot
cd ~/projects/n8n-automations/saljrobot && docker compose up -d

# Stoppa säljrobot
cd ~/projects/n8n-automations/saljrobot && docker compose down

# Visa loggar
cd ~/projects/n8n-automations/saljrobot && docker compose logs -f

# Backup
cd ~/projects/n8n-automations/saljrobot && ./scripts/backup.sh

# Uppdatera n8n
cd ~/projects/n8n-automations/saljrobot && ./scripts/update.sh

# Se alla containers
docker ps

# Starta om allt
cd ~/projects/n8n-automations/saljrobot && docker compose restart
```

## Nästa steg

1. ✅ SSH in till hemservern
2. ✅ Installera Docker
3. ✅ Klona/kopiera projektet
4. ✅ Starta säljroboten
5. ✅ Öppna från jobbet via Tailscale
6. ⚙️ Konfigurera workflows
7. 🚀 Sätt igång automatisk lead-generering!

## Support

Om du stöter på problem:
1. Kolla loggar: `docker compose logs -f`
2. Verifiera åtkomst: `curl http://localhost:5679/healthz`
3. Testa från annat nätverk: Via Tailscale

Lycka till! 🚀
