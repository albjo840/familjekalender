#!/bin/bash

# Quick Deploy Script - n8n Automations
# Kör detta skript på din hemserver för att snabbt sätta upp allt

set -e

# Färger för output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}   n8n Automations - Hemserver Setup${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""

# Kontrollera att vi är på rätt plats
if [ ! -f "create-project.sh" ]; then
    echo -e "${RED}❌ Fel: Kör skriptet från n8n-automations mappen${NC}"
    echo -e "${YELLOW}cd ~/projects/n8n-automations && ./deploy-to-server.sh${NC}"
    exit 1
fi

# 1. Kontrollera Docker
echo -e "${YELLOW}🔍 Kontrollerar Docker...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}⚠️  Docker är inte installerat. Installerar...${NC}"
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    echo -e "${GREEN}✅ Docker installerat!${NC}"
    echo -e "${YELLOW}⚠️  Du behöver logga ut och in igen för att använda Docker${NC}"
    echo -e "${YELLOW}   Eller kör: newgrp docker${NC}"
    exit 0
else
    echo -e "${GREEN}✅ Docker är installerat: $(docker --version)${NC}"
fi

# 2. Hitta tillgängliga projekt
echo ""
echo -e "${BLUE}📋 Tillgängliga projekt:${NC}"

# Lista alla projekt-mappar (utom _template)
PROJECT_DIRS=($(find . -maxdepth 1 -type d ! -name "." ! -name ".git" ! -name "_template" -printf "%f\n" | sort))

if [ ${#PROJECT_DIRS[@]} -eq 0 ]; then
    echo -e "${RED}❌ Inga projekt hittades!${NC}"
    echo -e "${YELLOW}Skapa ett projekt först:${NC}"
    echo -e "  ./create-project.sh mitt-projekt 5678"
    exit 1
fi

# Visa tillgängliga projekt
i=1
for dir in "${PROJECT_DIRS[@]}"; do
    if [ -f "$dir/docker-compose.yml" ]; then
        echo "$i) $dir"
        ((i++))
    fi
done
echo "$i) Alla projekt"
echo ""

read -p "Välj projekt (1-$i): " choice

# Validera val
if ! [[ "$choice" =~ ^[0-9]+$ ]] || [ "$choice" -lt 1 ] || [ "$choice" -gt "$i" ]; then
    echo -e "${RED}❌ Ogiltigt val${NC}"
    exit 1
fi

# Sätt projekt att starta
if [ "$choice" -eq "$i" ]; then
    # Alla projekt
    PROJECTS=()
    for dir in "${PROJECT_DIRS[@]}"; do
        if [ -f "$dir/docker-compose.yml" ]; then
            PROJECTS+=("$dir")
        fi
    done
else
    # Specifikt projekt
    selected_index=$((choice - 1))
    valid_projects=()
    for dir in "${PROJECT_DIRS[@]}"; do
        if [ -f "$dir/docker-compose.yml" ]; then
            valid_projects+=("$dir")
        fi
    done
    PROJECTS=("${valid_projects[$selected_index]}")
fi

# 3. Starta valda projekt
for project in "${PROJECTS[@]}"; do
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}🚀 Startar: ${project}${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

    if [ ! -d "$project" ]; then
        echo -e "${RED}❌ Projekt $project finns inte!${NC}"
        continue
    fi

    cd "$project"

    # Kontrollera .env
    if [ ! -f ".env" ]; then
        echo -e "${YELLOW}📝 Skapar .env från .env.example...${NC}"
        cp .env.example .env

        # Generera nytt lösenord
        NEW_PASSWORD=$(openssl rand -base64 16 2>/dev/null || date +%s | sha256sum | base64 | head -c 16)
        sed -i "s/N8N_BASIC_AUTH_PASSWORD=.*/N8N_BASIC_AUTH_PASSWORD=${NEW_PASSWORD}/" .env
        echo -e "${GREEN}✅ .env skapad med nytt lösenord${NC}"
    fi

    # Hämta port från .env
    PORT=$(grep "N8N_PORT=" .env | cut -d= -f2)
    PASSWORD=$(grep "N8N_BASIC_AUTH_PASSWORD=" .env | cut -d= -f2)

    # Starta med Docker Compose
    echo -e "${YELLOW}🐳 Startar Docker containers...${NC}"
    docker compose up -d

    # Vänta lite
    echo -e "${YELLOW}⏳ Väntar på att n8n ska starta...${NC}"
    sleep 5

    # Kontrollera status
    if docker compose ps | grep -q "Up"; then
        echo -e "${GREEN}✅ ${project} är igång!${NC}"
        echo ""
        echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo -e "${GREEN}📍 Åtkomst:${NC}"
        echo -e "   Lokal:     ${BLUE}http://localhost:${PORT}${NC}"

        # Försök hitta Tailscale IP
        if command -v tailscale &> /dev/null; then
            TAILSCALE_IP=$(tailscale ip -4 2>/dev/null || echo "100.81.105.182")
            echo -e "   Tailscale: ${BLUE}http://${TAILSCALE_IP}:${PORT}${NC}"
        fi

        echo ""
        echo -e "${GREEN}🔐 Login:${NC}"
        echo -e "   Användarnamn: ${BLUE}admin${NC}"
        echo -e "   Lösenord:     ${BLUE}${PASSWORD}${NC}"
        echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    else
        echo -e "${RED}❌ Något gick fel vid start av ${project}${NC}"
        echo -e "${YELLOW}Loggar:${NC}"
        docker compose logs --tail=20
    fi

    cd ..
done

# 4. Sammanfattning
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✨ Installation klar!${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}📝 Användbara kommandon:${NC}"
echo ""
echo -e "  ${YELLOW}Se status:${NC}"
echo -e "    docker ps"
echo ""
echo -e "  ${YELLOW}Stoppa projekt:${NC}"
echo -e "    cd <projekt> && docker compose down"
echo ""
echo -e "  ${YELLOW}Visa loggar:${NC}"
echo -e "    cd <projekt> && docker compose logs -f"
echo ""
echo -e "  ${YELLOW}Backup:${NC}"
echo -e "    cd <projekt> && ./scripts/backup.sh"
echo ""
echo -e "  ${YELLOW}Uppdatera n8n:${NC}"
echo -e "    cd <projekt> && ./scripts/update.sh"
echo ""
echo -e "${GREEN}🚀 Öppna n8n i din webbläsare och börja skapa workflows!${NC}"
echo ""
