#!/bin/bash

# Skript för att kopiera n8n-automations till hemservern
# Kör från jobbdatorn

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}   Kopiera n8n-automations till Hemserver${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo ""

# Hemserver-info
HOMESERVER_TAILSCALE="100.81.105.182"
HOMESERVER_VPN="10.0.0.1"
HOMESERVER_DUCKDNS="taborsen.duckdns.org"

echo -e "${BLUE}Välj anslutningsmetod:${NC}"
echo "1) Tailscale (100.81.105.182) - Rekommenderat"
echo "2) WireGuard VPN (10.0.0.1)"
echo "3) DuckDNS (taborsen.duckdns.org)"
echo "4) Annan adress"
echo ""
read -p "Välj (1-4): " choice

case $choice in
    1)
        SERVER="$HOMESERVER_TAILSCALE"
        ;;
    2)
        SERVER="$HOMESERVER_VPN"
        ;;
    3)
        SERVER="$HOMESERVER_DUCKDNS"
        ;;
    4)
        read -p "Ange adress: " SERVER
        ;;
    *)
        echo -e "${RED}❌ Ogiltigt val${NC}"
        exit 1
        ;;
esac

# Användarnamn
read -p "Användarnamn på hemservern [user]: " USERNAME
USERNAME=${USERNAME:-user}

TARGET="${USERNAME}@${SERVER}"

echo ""
echo -e "${YELLOW}📦 Skapar arkiv...${NC}"

# Gå till rätt katalog
cd /home/user

# Skapa arkiv (exkludera .git för mindre storlek)
tar -czf n8n-automations.tar.gz \
    --exclude='n8n-automations/.git' \
    --exclude='n8n-automations/*/data' \
    --exclude='n8n-automations/*/.env' \
    n8n-automations/

SIZE=$(du -h n8n-automations.tar.gz | cut -f1)
echo -e "${GREEN}✅ Arkiv skapat: n8n-automations.tar.gz (${SIZE})${NC}"

echo ""
echo -e "${YELLOW}📤 Kopierar till ${TARGET}...${NC}"

# Kopiera med scp
scp n8n-automations.tar.gz "${TARGET}:~/"

echo -e "${GREEN}✅ Kopiering klar!${NC}"

echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}✨ Nästa steg (på hemservern):${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${YELLOW}# SSH till hemservern${NC}"
echo -e "ssh ${TARGET}"
echo ""
echo -e "${YELLOW}# Packa upp arkivet${NC}"
echo -e "cd ~"
echo -e "tar -xzf n8n-automations.tar.gz"
echo ""
echo -e "${YELLOW}# Kör deploy-skript${NC}"
echo -e "cd n8n-automations"
echo -e "./deploy-to-server.sh"
echo ""
echo -e "${GREEN}🚀 Sedan är n8n igång och redo att användas!${NC}"
echo ""

# Cleanup
rm n8n-automations.tar.gz
echo -e "${BLUE}🧹 Lokal arkiv-fil raderad${NC}"
echo ""
