#!/bin/bash

# Skript för att skapa GitHub repo och pusha
# Kör efter att du skapat repot på GitHub

echo "════════════════════════════════════════════════════════"
echo "  GitHub Repository Setup"
echo "════════════════════════════════════════════════════════"
echo ""
echo "STEG 1: Skapa repo på GitHub"
echo "----------------------------"
echo ""
echo "1. Öppna din webbläsare och gå till:"
echo "   https://github.com/new"
echo ""
echo "2. Fyll i formuläret:"
echo "   Repository name:  n8n-automations"
echo "   Description:      n8n automation framework med säljrobot"
echo "   Visibility:       ✅ Public"
echo "   Initialize:       ❌ KRYSSA INTE i 'Add a README file'"
echo ""
echo "3. Klicka 'Create repository'"
echo ""
read -p "Tryck ENTER när du har skapat repot på GitHub..."
echo ""

echo "════════════════════════════════════════════════════════"
echo "STEG 2: Personal Access Token (PAT)"
echo "════════════════════════════════════════════════════════"
echo ""
echo "GitHub kräver en Personal Access Token istället för lösenord."
echo ""
echo "1. Öppna i ny flik:"
echo "   https://github.com/settings/tokens"
echo ""
echo "2. Klicka 'Generate new token' → 'Generate new token (classic)'"
echo ""
echo "3. Fyll i:"
echo "   Note:        n8n-automations"
echo "   Expiration:  90 days (eller längre)"
echo "   Scopes:      ✅ Kryssa i 'repo' (full repository access)"
echo ""
echo "4. Klicka 'Generate token'"
echo ""
echo "5. KOPIERA TOKEN NU! (visas bara en gång)"
echo "   Token ser ut typ: ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
echo ""
read -p "Tryck ENTER när du har kopierat din PAT..."
echo ""

echo "════════════════════════════════════════════════════════"
echo "STEG 3: Konfigurera Git och Pusha"
echo "════════════════════════════════════════════════════════"
echo ""

# Kontrollera att vi är i rätt katalog
if [ ! -f "create-project.sh" ]; then
    echo "❌ Fel: Måste köras från n8n-automations mappen"
    echo "Kör: cd /home/user/n8n-automations && ./github-setup.sh"
    exit 1
fi

# Visa aktuell status
echo "📊 Aktuell status:"
git log --oneline | head -5
echo ""
echo "Totalt: $(git log --oneline | wc -l) commits"
echo "Storlek: $(du -sh . | cut -f1)"
echo ""

# Lägg till remote
echo "🔗 Lägger till GitHub remote..."
if git remote | grep -q "^origin$"; then
    echo "⚠️  Remote 'origin' finns redan. Uppdaterar..."
    git remote remove origin
fi

git remote add origin https://github.com/albjo840/n8n-automations.git
echo "✅ Remote tillagd: https://github.com/albjo840/n8n-automations.git"
echo ""

# Byt till main branch
echo "🔄 Byter till main branch..."
git branch -M main
echo "✅ Branch: main"
echo ""

# Pusha
echo "════════════════════════════════════════════════════════"
echo "🚀 PUSHAR TILL GITHUB"
echo "════════════════════════════════════════════════════════"
echo ""
echo "När det frågar efter credentials:"
echo "  Username: albjo840"
echo "  Password: KLISTRA IN DIN PAT (inte vanligt lösenord!)"
echo ""
read -p "Tryck ENTER för att starta push..."
echo ""

if git push -u origin main; then
    echo ""
    echo "════════════════════════════════════════════════════════"
    echo "✅ SUCCESS! Repository pushat till GitHub"
    echo "════════════════════════════════════════════════════════"
    echo ""
    echo "🎉 Ditt repository finns nu på:"
    echo "   https://github.com/albjo840/n8n-automations"
    echo ""
    echo "📄 Skapa PDF av pitch:"
    echo "   1. Öppna: https://github.com/albjo840/n8n-automations/blob/main/saljrobot/PITCH_SAMMANFATTNING.md"
    echo "   2. Tryck Ctrl+P (Print)"
    echo "   3. Välj 'Save as PDF'"
    echo ""
    echo "🚀 Nästa steg - Starta säljroboten:"
    echo "   cd /home/user/n8n-automations"
    echo "   ./deploy-to-server.sh"
    echo ""
else
    echo ""
    echo "════════════════════════════════════════════════════════"
    echo "❌ Push misslyckades"
    echo "════════════════════════════════════════════════════════"
    echo ""
    echo "Vanliga problem:"
    echo ""
    echo "1. Authentication failed:"
    echo "   - Använd PAT, INTE vanligt lösenord"
    echo "   - Skapa ny PAT om den gamla inte fungerar"
    echo ""
    echo "2. Repository not found:"
    echo "   - Kolla att du skapade repot som 'albjo840'"
    echo "   - Kolla att repot heter 'n8n-automations'"
    echo "   - Skapa det på: https://github.com/new"
    echo ""
    echo "3. Permission denied:"
    echo "   - Kolla att PAT har 'repo' scope"
    echo ""
    echo "Försök igen? Kör:"
    echo "  cd /home/user/n8n-automations && ./github-setup.sh"
fi
