# n8n Automations

Ett modulärt system för att hantera n8n-automatiseringsprojekt med Docker. Enkelt att sätta upp nya projekt och hantera dem separat.

## Översikt

Detta repository innehåller:
- **_template/**: Mall för nya n8n-projekt
- **create-project.sh**: Skript för att snabbt skapa nya projekt
- Separata mappar för varje automatiseringsprojekt

## Snabbstart

### 1. Skapa ett nytt projekt

```bash
./create-project.sh mitt-projekt 5678
```

Detta skapar en ny mapp `mitt-projekt` med:
- Docker Compose-konfiguration
- Miljövariabler (.env)
- Backup/restore-skript
- Dokumentation

### 2. Starta projektet

```bash
cd mitt-projekt
docker-compose up -d
```

### 3. Öppna n8n

Gå till `http://localhost:5678` och logga in med:
- **Användarnamn**: admin
- **Lösenord**: Se i projektets `.env`-fil

## Projektstruktur

```
n8n-automations/
├── _template/              # Mall för nya projekt
│   ├── docker-compose.yml  # Docker-konfiguration
│   ├── .env.example        # Miljövariabler (exempel)
│   ├── .gitignore          # Git ignore-regler
│   ├── workflows/          # n8n workflows (versionskontrollerade)
│   ├── data/               # Datalagring (ej versionskontrollerad)
│   ├── backups/            # Backup-filer
│   └── scripts/            # Hjälpskript
│       ├── backup.sh       # Skapa backup
│       ├── restore.sh      # Återställ från backup
│       └── update.sh       # Uppdatera n8n
├── create-project.sh       # Skapa nytt projekt
└── projekt1/               # Dina projekt skapas här
    └── projekt2/
```

## Skapa nya projekt

### Grundläggande användning

```bash
./create-project.sh <projekt-namn> [port]
```

**Exempel:**

```bash
# Skapa projekt på standardport 5678
./create-project.sh mitt-projekt

# Skapa projekt på specifik port
./create-project.sh telegram-bot 5679
```

### Multipla projekt

Du kan köra flera n8n-instanser samtidigt, var och en på sin egen port:

```bash
./create-project.sh projekt1 5678
./create-project.sh projekt2 5679
./create-project.sh projekt3 5680
```

## Hantera projekt

### Starta ett projekt

```bash
cd mitt-projekt
docker-compose up -d
```

### Stoppa ett projekt

```bash
docker-compose down
```

### Visa loggar

```bash
docker-compose logs -f n8n
```

### Starta om

```bash
docker-compose restart
```

### Uppdatera n8n

```bash
./scripts/update.sh
```

## Backup och återställning

### Skapa backup

```bash
cd mitt-projekt
./scripts/backup.sh
```

Backupen sparas i `backups/` och innehåller:
- Workflows
- Data och databas
- Konfiguration (.env)

### Återställ från backup

```bash
./scripts/restore.sh backups/mitt-projekt_backup_20250127_120000.tar.gz
```

### Automatiska backups

De 10 senaste backuperna behålls automatiskt. Äldre backups tas bort.

## Konfiguration

Varje projekt har sin egen `.env`-fil med konfiguration:

```env
PROJECT_NAME=mitt-projekt
N8N_PORT=5678
N8N_HOST=localhost
N8N_PROTOCOL=http

# Autentisering
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=ditt-lösenord

# Tidszon
TIMEZONE=Europe/Stockholm

# Webhooks
WEBHOOK_URL=http://localhost:5678/
```

## Databas

### SQLite (Standard)

Standard är SQLite, vilket är enkelt och fungerar bra för de flesta fall:
- Ingen extra konfiguration behövs
- Data sparas i `data/database.sqlite`
- Perfekt för personligt bruk

### PostgreSQL (Valfritt)

För mer avancerade behov, aktivera PostgreSQL:

1. Redigera `docker-compose.yml` och avkommentera postgres-service
2. Uppdatera `.env`:
   ```env
   DB_TYPE=postgresdb
   DB_POSTGRESDB_HOST=postgres
   DB_POSTGRESDB_PORT=5432
   POSTGRES_USER=n8n
   POSTGRES_PASSWORD=ditt-lösenord
   POSTGRES_DB=n8n
   ```
3. Starta om: `docker-compose up -d`

## Workflows och versionskontroll

### Lagra workflows i Git

Workflows sparas i `workflows/`-mappen och kan versionskontrolleras:

```bash
cd mitt-projekt
git add workflows/
git commit -m "Lägg till nytt workflow"
git push
```

### Exportera workflow från n8n

1. Öppna n8n i webbläsaren
2. Gå till ditt workflow
3. Klicka på "Download" eller använd export-funktionen
4. Spara filen i `workflows/`

### Importera workflow till n8n

1. Kopiera workflow-filer till `workflows/`
2. Öppna n8n
3. Klicka på "Import from File"
4. Välj filen från `workflows/`

## Tips och tricks

### Exponera n8n till internet

För att använda webhooks från externa tjänster (t.ex. GitHub, Telegram):

1. Använd en reverse proxy (nginx, Caddy, Traefik)
2. Eller använd en tunnel-tjänst (ngrok, Cloudflare Tunnel)
3. Uppdatera `WEBHOOK_URL` i `.env`

### Använda med hemserver

För att köra på din hemserver:

1. Installera Docker och Docker Compose
2. Klona detta repository
3. Skapa projekt och starta
4. Sätt upp port forwarding i din router (valfritt)
5. Konfigurera domännamn eller DynDNS (valfritt)

### Migrera mellan projekt

```bash
# Skapa backup från källprojekt
cd projekt1
./scripts/backup.sh

# Återställ i målprojekt
cd ../projekt2
./scripts/restore.sh ../projekt1/backups/projekt1_backup_XXXXXX.tar.gz
```

### Övervaka flera projekt

Använd Docker Compose labels och portainer eller kör:

```bash
# Lista alla n8n-containers
docker ps | grep n8n

# Visa loggar från alla
docker-compose logs -f
```

## Felsökning

### Port redan används

Om porten är upptagen, välj en annan:
```bash
./create-project.sh mitt-projekt 5679
```

### Container startar inte

Kontrollera loggar:
```bash
docker-compose logs n8n
```

### Data försvinner vid omstart

Kontrollera att volumes är korrekt monterade:
```bash
docker-compose config
```

### Glömt lösenord

Hitta lösenordet i `.env`:
```bash
grep PASSWORD .env
```

Eller återställ det:
```bash
# Redigera .env och ändra N8N_BASIC_AUTH_PASSWORD
nano .env

# Starta om
docker-compose restart
```

## Säkerhet

### Rekommendationer

1. **Ändra standardlösenord**: Varje projekt får ett unikt lösenord, men ändra vid behov
2. **Exponera inte utan skydd**: Använd HTTPS och stark autentisering
3. **Backupa regelbundet**: Kör `./scripts/backup.sh` regelbundet
4. **Uppdatera regelbundet**: Kör `./scripts/update.sh` för säkerhetsuppdateringar
5. **Begränsa åtkomst**: Använd firewall-regler för att begränsa åtkomst

### .env-filer

`.env`-filer innehåller känslig information och gitignoreras automatiskt.

## Resurser

- [n8n Dokumentation](https://docs.n8n.io/)
- [n8n Community](https://community.n8n.io/)
- [n8n Workflows](https://n8n.io/workflows/)
- [Docker Dokumentation](https://docs.docker.com/)

## Licens

Detta är en mall för personligt bruk. n8n har sin egen licens - se [n8n.io](https://n8n.io/).

## Support

För frågor om:
- **n8n**: Se [n8n documentation](https://docs.n8n.io/)
- **Docker**: Se [Docker documentation](https://docs.docker.com/)
- **Denna mall**: Öppna en issue i detta repository
