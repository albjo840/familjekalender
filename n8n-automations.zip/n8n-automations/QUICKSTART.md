# Snabbstartsguide - n8n Automations

## Kom igång på 5 minuter

### 1. Skapa ditt första projekt

```bash
cd /home/user/n8n-automations
./create-project.sh mitt-projekt 5678
```

### 2. Starta projektet

```bash
cd mitt-projekt
docker-compose up -d
```

### 3. Öppna n8n

Öppna webbläsaren och gå till: http://localhost:5678

Logga in med:
- Användarnamn: `admin`
- Lösenord: (finns i `.env`-filen)

### 4. Skapa ditt första workflow

1. Klicka på "Create Workflow"
2. Lägg till noder (t.ex. Webhook, HTTP Request)
3. Konfigurera och aktivera
4. Testa!

## Exempel: Säljrobot för Lead-generering

Vi har skapat ett exempel-projekt som du kan använda som utgångspunkt:

```bash
cd /home/user/n8n-automations/saljrobot
docker-compose up -d
```

Detta projekt kan användas för att:
- Scrapa företag från Allabolag/Ratsit
- Hitta och validera email-adresser
- Poängsätta och kvalificera leads
- Exportera till CRM (Pipedrive, HubSpot)
- Skicka notifikationer via Telegram
- Och mycket mer!

## Vanliga kommandon

### Starta projekt
```bash
docker-compose up -d
```

### Stoppa projekt
```bash
docker-compose down
```

### Visa loggar
```bash
docker-compose logs -f
```

### Backup
```bash
./scripts/backup.sh
```

### Uppdatera n8n
```bash
./scripts/update.sh
```

## Skapa fler projekt

Du kan ha flera projekt igång samtidigt:

```bash
./create-project.sh telegram-bot 5679
./create-project.sh github-automation 5680
./create-project.sh iot-dashboard 5681
```

Varje projekt körs på sin egen port och är helt isolerat!

## Nästa steg

- Läs [README.md](README.md) för detaljerad dokumentation
- Utforska [n8n dokumentation](https://docs.n8n.io/)
- Kolla in [n8n workflows](https://n8n.io/workflows/) för inspiration
- Anslut till dina tjänster (Telegram, Google, GitHub, etc.)

## Behöver hjälp?

- n8n dokumentation: https://docs.n8n.io/
- n8n community: https://community.n8n.io/
- Docker dokumentation: https://docs.docker.com/

Ha kul med automationerna!
