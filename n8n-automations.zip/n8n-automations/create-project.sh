#!/bin/bash

# Skript för att skapa ett nytt n8n-automatiseringsprojekt från mallen
# Användning: ./create-project.sh <projekt-namn> [port]

set -e

# Färger för output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Kontrollera argument
if [ -z "$1" ]; then
    echo -e "${RED}❌ Användning: ./create-project.sh <projekt-namn> [port]${NC}"
    echo -e "${BLUE}Exempel: ./create-project.sh telegram-bot 5678${NC}"
    exit 1
fi

PROJECT_NAME=$1
PORT=${2:-5678}
PROJECT_DIR="./${PROJECT_NAME}"

# Kontrollera att projektet inte redan finns
if [ -d "${PROJECT_DIR}" ]; then
    echo -e "${RED}❌ Projekt ${PROJECT_NAME} finns redan!${NC}"
    exit 1
fi

# Kontrollera att mallen finns
if [ ! -d "./_template" ]; then
    echo -e "${RED}❌ Mall-katalog (_template) hittades inte!${NC}"
    exit 1
fi

echo -e "${BLUE}🚀 Skapar nytt n8n-projekt: ${PROJECT_NAME}${NC}"
echo ""

# Kopiera mall
echo -e "${YELLOW}📋 Kopierar mall...${NC}"
cp -r ./_template "${PROJECT_DIR}"

# Skapa .env från exempel
cd "${PROJECT_DIR}"
cp .env.example .env

# Uppdatera .env med projektspecifika värden
echo -e "${YELLOW}⚙️  Konfigurerar projekt...${NC}"
sed -i "s/PROJECT_NAME=.*/PROJECT_NAME=${PROJECT_NAME}/" .env
sed -i "s/N8N_PORT=.*/N8N_PORT=${PORT}/" .env
sed -i "s|WEBHOOK_URL=.*|WEBHOOK_URL=http://localhost:${PORT}/|" .env

# Generera ett slumpmässigt lösenord
RANDOM_PASSWORD=$(openssl rand -base64 12 2>/dev/null || echo "changeme123!")
sed -i "s/N8N_BASIC_AUTH_PASSWORD=.*/N8N_BASIC_AUTH_PASSWORD=${RANDOM_PASSWORD}/" .env

# Gör skript körbara
chmod +x scripts/*.sh 2>/dev/null || true

# Skapa README för projektet
cat > README.md << EOF
# ${PROJECT_NAME}

n8n-automatiseringsprojekt skapat: $(date +%Y-%m-%d)

## Snabbstart

\`\`\`bash
# Starta projektet
docker-compose up -d

# Visa loggar
docker-compose logs -f

# Stoppa projektet
docker-compose down

# Backup
./scripts/backup.sh

# Återställ från backup
./scripts/restore.sh backups/<backup-fil>
\`\`\`

## Åtkomst

- URL: http://localhost:${PORT}
- Användarnamn: admin
- Lösenord: Se .env-filen (N8N_BASIC_AUTH_PASSWORD)

## Kataloger

- \`workflows/\` - Dina n8n workflows (versionskontrollerade)
- \`data/\` - n8n data och databas (gitignorerad)
- \`backups/\` - Automatiska backups
- \`scripts/\` - Hjälpskript

## Kommandon

\`\`\`bash
# Starta
docker-compose up -d

# Stoppa
docker-compose down

# Starta om
docker-compose restart

# Visa loggar
docker-compose logs -f n8n

# Uppdatera n8n
docker-compose pull
docker-compose up -d

# Backup
./scripts/backup.sh

# Återställ
./scripts/restore.sh backups/<fil>
\`\`\`

## Konfiguration

Redigera \`.env\` för att ändra:
- Port
- Autentisering
- Databas (SQLite eller PostgreSQL)
- Webhook-URL
- Och mer...
EOF

cd ..

echo ""
echo -e "${GREEN}✅ Projekt skapat: ${PROJECT_DIR}${NC}"
echo ""
echo -e "${BLUE}📝 Nästa steg:${NC}"
echo -e "  1. cd ${PROJECT_NAME}"
echo -e "  2. Granska och uppdatera .env-filen vid behov"
echo -e "  3. docker-compose up -d"
echo -e "  4. Öppna http://localhost:${PORT}"
echo ""
echo -e "${YELLOW}🔐 Inloggningsuppgifter:${NC}"
echo -e "  Användarnamn: admin"
echo -e "  Lösenord: ${RANDOM_PASSWORD}"
echo ""
echo -e "${BLUE}💡 Tips: Spara lösenordet! Det finns även i ${PROJECT_NAME}/.env${NC}"
echo ""
