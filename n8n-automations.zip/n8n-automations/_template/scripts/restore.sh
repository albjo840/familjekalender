#!/bin/bash

# Återställningsskript för n8n-projekt
# Återställer från en backup-fil

set -e

# Kontrollera argument
if [ -z "$1" ]; then
    echo "❌ Användning: ./restore.sh <backup-fil>"
    echo ""
    echo "Tillgängliga backups:"
    ls -lh backups/*.tar.gz 2>/dev/null || echo "Inga backups hittades"
    exit 1
fi

BACKUP_FILE="$1"

# Kontrollera att backup-filen finns
if [ ! -f "${BACKUP_FILE}" ]; then
    echo "❌ Backup-fil hittades inte: ${BACKUP_FILE}"
    exit 1
fi

echo "⚠️  VARNING: Detta kommer att skriva över befintliga data!"
read -p "Vill du fortsätta? (ja/nej): " confirm

if [ "$confirm" != "ja" ]; then
    echo "Avbruten"
    exit 0
fi

echo "🔄 Återställer från ${BACKUP_FILE}..."

# Stoppa containers om de körs
docker-compose down 2>/dev/null || true

# Skapa backup av nuvarande tillstånd
if [ -d "data" ] || [ -d "workflows" ]; then
    TEMP_BACKUP="backups/pre_restore_$(date +%Y%m%d_%H%M%S).tar.gz"
    echo "💾 Skapar säkerhetskopia av nuvarande tillstånd: ${TEMP_BACKUP}"
    tar -czf "${TEMP_BACKUP}" data/ workflows/ .env 2>/dev/null || true
fi

# Extrahera backup
echo "📦 Extraherar backup..."
tar -xzf "${BACKUP_FILE}"

echo "✅ Återställning klar!"
echo "🚀 Starta projektet med: docker-compose up -d"
