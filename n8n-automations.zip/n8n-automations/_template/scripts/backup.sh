#!/bin/bash

# Backup-skript för n8n-projekt
# Skapar en komplett backup av workflows, data och konfiguration

set -e

# Konfigurera variabler
BACKUP_DIR="./backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
PROJECT_NAME=${PROJECT_NAME:-n8n}
BACKUP_FILE="${BACKUP_DIR}/${PROJECT_NAME}_backup_${TIMESTAMP}.tar.gz"

# Skapa backup-katalog om den inte finns
mkdir -p "${BACKUP_DIR}"

echo "🔄 Skapar backup av ${PROJECT_NAME}..."

# Skapa backup
tar -czf "${BACKUP_FILE}" \
    --exclude='backups' \
    --exclude='data/*.log' \
    data/ \
    workflows/ \
    .env \
    docker-compose.yml \
    2>/dev/null || true

# Kontrollera att backup skapades
if [ -f "${BACKUP_FILE}" ]; then
    BACKUP_SIZE=$(du -h "${BACKUP_FILE}" | cut -f1)
    echo "✅ Backup skapad: ${BACKUP_FILE} (${BACKUP_SIZE})"

    # Ta bort gamla backups (behåll senaste 10)
    cd "${BACKUP_DIR}"
    ls -t ${PROJECT_NAME}_backup_*.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm
    echo "🧹 Gamla backups rensade (behåller 10 senaste)"
else
    echo "❌ Fel vid skapande av backup"
    exit 1
fi

echo "✨ Backup klar!"
