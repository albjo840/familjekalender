#!/bin/bash

# Uppdateringsskript för n8n
# Uppdaterar n8n till senaste versionen

set -e

echo "🔄 Uppdaterar n8n till senaste versionen..."

# Skapa backup först
echo "💾 Skapar backup innan uppdatering..."
./backup.sh

echo "📥 Hämtar senaste n8n-image..."
docker-compose pull

echo "🔄 Startar om med ny version..."
docker-compose up -d

echo "✅ Uppdatering klar!"
echo "📊 Kontrollera status med: docker-compose logs -f"
