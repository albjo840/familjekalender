# Quick Start - n8n på Hemservern

Ultra-snabb guide för att komma igång på 5 minuter!

## Från jobbet: Kopiera projektet till hemservern

### Metod 1: Via Tailscale (Enklast)

```bash
# På jobbdatorn (där du är nu)
cd /home/user
tar -czf n8n-automations.tar.gz n8n-automations/

# Kopiera till hemservern via Tailscale
scp n8n-automations.tar.gz user@100.81.105.182:~/
```

### Metod 2: Via GitHub (Rekommenderat)

**Steg 1 - På jobbet (skapa repo):**
```bash
# Gå till https://github.com och skapa nytt repository
# Namn: n8n-automations
# Private eller Public (din val)

# Sedan:
cd /home/user/n8n-automations
git remote add origin https://github.com/ditt-användarnamn/n8n-automations.git
git branch -M main
git push -u origin main
```

**Steg 2 - Hemma (klona):**
```bash
# SSH till hemservern
ssh user@100.81.105.182

# Klona projektet
cd ~
git clone https://github.com/ditt-användarnamn/n8n-automations.git
cd n8n-automations
```

## På hemservern: Installera och starta

### Super-snabb installation (ett kommando)

```bash
# SSH till hemservern
ssh user@100.81.105.182

# Om du kopierade med tar.gz:
cd ~
tar -xzf n8n-automations.tar.gz
cd n8n-automations

# Kör deploy-skriptet
./deploy-to-server.sh
```

Det är allt! Skriptet gör:
- ✅ Installerar Docker (om inte installerat)
- ✅ Startar projekten du väljer
- ✅ Visar inloggningsuppgifter
- ✅ Ger dig åtkomst-URLer

### Manuell installation (om du vill ha kontroll)

```bash
# 1. Installera Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
newgrp docker

# 2. Starta säljroboten
cd ~/n8n-automations/saljrobot
docker compose up -d

# 3. Öppna i webbläsare
```

## Åtkomst från jobbet

### Via Tailscale (Rekommenderat ⭐)

**URL:** `http://100.81.105.182:5679`

**Login:**
- Användarnamn: `admin`
- Lösenord: Kör `cat ~/n8n-automations/saljrobot/.env | grep PASSWORD` på hemservern

**Fördelar:**
- ✅ Säker, krypterad förbindelse
- ✅ Ingen konfiguration behövs
- ✅ Fungerar överallt
- ✅ Ingen port forwarding

### Via WireGuard VPN

**URL:** `http://10.0.0.1:5679`

Aktivera WireGuard VPN först, sedan öppna URL:en.

### Via Internet (Avancerat)

Se `HEMSERVER_SETUP.md` för att sätta upp:
- Nginx reverse proxy
- SSL-certifikat
- DuckDNS subdomain

## Portar

```
Säljrobot:           5679
Familjekalender:     5678
Dina nya projekt:    5680+
```

## Snabbkommandon (på hemservern)

```bash
# Se alla containers
docker ps

# Starta projekt
cd ~/n8n-automations/saljrobot && docker compose up -d

# Stoppa projekt
cd ~/n8n-automations/saljrobot && docker compose down

# Visa loggar (live)
cd ~/n8n-automations/saljrobot && docker compose logs -f

# Backup
cd ~/n8n-automations/saljrobot && ./scripts/backup.sh

# Starta om
cd ~/n8n-automations/saljrobot && docker compose restart

# Uppdatera n8n
cd ~/n8n-automations/saljrobot && ./scripts/update.sh
```

## Första gången i n8n UI

1. **Öppna:** `http://100.81.105.182:5679`
2. **Logga in** med användarnamn/lösenord
3. **Importera workflow:**
   - Klicka "Import from File"
   - Välj `workflows/3-lead-scoring.json`
4. **Konfigurera credentials:**
   - Google Sheets
   - Telegram Bot
   - Hunter.io API (optional)
5. **Testa workflow** manuellt
6. **Aktivera** för automatisk körning

## Felsökning

### Kan inte ansluta

```bash
# På hemservern, testa lokalt
curl http://localhost:5679/healthz

# Kontrollera att container körs
docker ps | grep n8n

# Se loggar
cd ~/n8n-automations/saljrobot && docker compose logs -f
```

### Glömt lösenord

```bash
# På hemservern
cd ~/n8n-automations/saljrobot
cat .env | grep PASSWORD
```

### Port redan används

```bash
# Se vad som använder porten
sudo lsof -i :5679

# Eller ändra port i .env och starta om
nano .env  # Ändra N8N_PORT
docker compose restart
```

## Nästa steg

1. ✅ Kopiera projekt till hemserver
2. ✅ Kör deploy-skript
3. ✅ Öppna från jobbet
4. 🎨 Utforska n8n UI
5. 📊 Importera workflows
6. ⚙️ Konfigurera API-nycklar
7. 🚀 Starta automatisk lead-generering!

## Hjälp

- Detaljerad guide: `HEMSERVER_SETUP.md`
- Projektet: `README.md`
- Säljrobot: `saljrobot/README.md`
- Workflows: `saljrobot/workflows/README.md`

**Problem?** Kolla alltid loggar först:
```bash
docker compose logs -f
```

Lycka till! 🚀
