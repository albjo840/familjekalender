# Säljrobot Workflows

Workflows för automatiserad lead-generering till transportbolag.

## Översikt

Dessa workflows hjälper dig att:
1. Hitta företag som behöver transporter
2. Samla kontaktinformation
3. Kvalificera och poängsätta leads
4. Exportera till CRM eller Google Sheets

## Workflow 1: Allabolag Company Scraper

**Fil:** `1-allabolag-scraper.json`

**Beskrivning:** Scrapar företag från Allabolag.se baserat på sökkriterier.

**Komponenter:**
- Schedule Trigger (dagligen kl 08:00)
- HTTP Request till Allabolag.se
- HTML Extract (parsear företagsdata)
- Data transformation (rensa och strukturera)
- Google Sheets (spara resultat)

**Konfiguration:**
```javascript
// Sökkriterier
{
  "industry": ["Transport och magasinering", "Parti- och detaljhandel"],
  "minEmployees": 10,
  "maxEmployees": 100,
  "location": "Stockholm, Göteborg, Malmö",
  "minRevenue": 5000000
}
```

**Output:**
- Företagsnamn
- Organisationsnummer
- Bransch
- Antal anställda
- Omsättning
- Adress
- Telefon
- Hemsida

## Workflow 2: Email Finder & Validator

**Fil:** `2-email-finder.json`

**Beskrivning:** Hittar och validerar email-adresser för beslutsfattare.

**Komponenter:**
- Webhook eller Manual Trigger
- HTTP Request (hämta företag från Google Sheets)
- Hunter.io API (hitta email-adresser)
- Email pattern generator (gissa format)
- Email validator (verifiera email)
- Update Google Sheets (spara email)

**API-nycklar som behövs:**
- Hunter.io API key
- NeverBounce API key (optional)

**Funktioner:**
- Hitta VD, Inköpschef, Logistikansvarig
- Gissa email-format: fornamn.efternamn@företag.se
- Validera att email existerar
- Berika lead-data

## Workflow 3: Lead Scoring & Qualification

**Fil:** `3-lead-scoring.json`

**Beskrivning:** Poängsätter och kvalificerar leads baserat på kriterier.

**Poängsättning (0-100):**

```javascript
let score = 0;

// Omsättning
if (revenue > 50000000) score += 40;
else if (revenue > 20000000) score += 30;
else if (revenue > 10000000) score += 20;
else if (revenue > 5000000) score += 10;

// Antal anställda
if (employees > 50) score += 25;
else if (employees > 20) score += 20;
else if (employees >= 10) score += 15;

// Bransch (hög potential för transport)
const highValueIndustries = [
  'E-handel',
  'Grossist',
  'Tillverkning',
  'Byggföretag',
  'Distribution'
];
if (highValueIndustries.includes(industry)) score += 20;

// Hemsida aktiv
if (website && websiteActive) score += 5;

// Email hittad
if (email) score += 5;

// Email validerad
if (emailValid) score += 5;

return score;
```

**Kategorisering:**
- **Hot Lead (70-100p):** Kontakta omedelbart
- **Warm Lead (50-69p):** Lägg i pipeline
- **Cold Lead (<50p):** Nurture-kampanj

**Output:**
- Lead score
- Lead category (Hot/Warm/Cold)
- Rekommenderad action
- Prioritet

## Workflow 4: CRM Export & Notification

**Fil:** `4-crm-export.json`

**Beskrivning:** Exporterar kvalificerade leads till CRM och skickar notifikationer.

**Komponenter:**
- Schedule Trigger (varje timme)
- Filter (endast Hot & Warm leads)
- Pipedrive/HubSpot API (skapa deal)
- Telegram Bot (notifiera säljteam)
- Update Google Sheets (markera som exporterad)

**Telegram-notifikation:**
```
🔥 Ny Hot Lead!

Företag: [Namn]
Omsättning: [X] MSEK
Anställda: [Y]
Bransch: [Bransch]
Kontakt: [Namn] - [Email]
Lead Score: [Score]/100

🎯 Action: Kontakta inom 24h
```

**CRM-integration:**
- Skapa ny Deal/Contact
- Sätt lead source = "Säljrobot"
- Tilldela till säljare
- Sätt uppföljningsdatum

## Workflow 5: Website Analyzer

**Fil:** `5-website-analyzer.json`

**Beskrivning:** Analyserar företags hemsidor för att hitta transportbehov.

**Komponenter:**
- HTTP Request (hämta hemsida)
- HTML Extract (sök efter keywords)
- AI Analysis (optional: GPT-4 via OpenAI API)
- Scoring adjustment

**Keywords som indikerar transportbehov:**
- "leverans"
- "frakt"
- "logistik"
- "distribution"
- "lager"
- "e-handel"
- "webshop"
- "transport"

**AI-analys (optional):**
```
Analysera denna hemsida och besvara:
1. Har de e-handel/webshop?
2. Nämns leveranser eller frakt?
3. Har de eget lager?
4. Vilken typ av produkter säljer de?
5. Potentiellt transportbehov (1-10)?
```

## Workflow 6: Daily Lead Report

**Fil:** `6-daily-report.json`

**Beskrivning:** Daglig sammanfattning av nya leads.

**Komponenter:**
- Schedule Trigger (varje dag kl 17:00)
- Hämta dagens leads från Google Sheets
- Skapa rapport (HTML/Markdown)
- Skicka via Email eller Telegram

**Rapport innehåller:**
- Antal nya leads (totalt)
- Antal Hot/Warm/Cold leads
- Top 5 högst poängsatta leads
- Statistik per bransch
- Veckovis trend

**Exempel:**
```
📊 Daglig Lead-rapport - 2025-10-27

Nya leads idag: 47
🔥 Hot leads: 8
🌡️ Warm leads: 23
❄️ Cold leads: 16

Top 5 leads:
1. Företag AB (95p) - E-handel, 45 anställda
2. Transport XYZ (88p) - Grossist, 67 anställda
3. Logistik Co (82p) - Distribution, 34 anställda
...

Branscher:
- E-handel: 18 leads
- Grossist: 12 leads
- Tillverkning: 9 leads
...

Veckotrend: ↗️ +15% jämfört med förra veckan
```

## Installation och användning

### 1. Importera workflows

```bash
# I n8n UI:
# Workflow → Import from File → Välj .json-fil
```

### 2. Konfigurera Credentials

Lägg till i n8n:
- Google Sheets API
- Hunter.io API key
- Telegram Bot Token
- CRM API (Pipedrive/HubSpot)
- OpenAI API key (optional)

### 3. Anpassa sökkriterier

Redigera variabler i workflow 1:
```javascript
// Justera för din målgrupp
const searchCriteria = {
  industries: ["Din bransch"],
  location: "Din region",
  minEmployees: 10,
  maxEmployees: 200,
  minRevenue: 5000000
};
```

### 4. Testa manuellt

- Kör varje workflow manuellt först
- Verifiera att data ser korrekt ut
- Justera filters och scoring

### 5. Aktivera automation

- Aktivera Schedule Triggers
- Övervaka första dygnet
- Justera vid behov

## Tips och best practices

### Scraping

- **Rate limiting:** Vänta 2-3 sekunder mellan requests
- **User Agent:** Rotera mellan olika user agents
- **Robots.txt:** Respektera webbplatsens robots.txt
- **Error handling:** Hantera timeout och 404-errors

### Email-sökning

- **Flera källor:** Använd både API och pattern matching
- **Validering:** Validera alltid emails innan kontakt
- **GDPR:** Spara endast nödvändig data

### Lead-kvalificering

- **Justera kriterier:** Baserat på dina erfarenheter
- **A/B-test:** Testa olika scoring-modeller
- **Feedback loop:** Uppdatera baserat på konverteringar

### CRM-integration

- **Deduplicering:** Kontrollera duplicates innan import
- **Data mapping:** Matcha fält korrekt
- **Error handling:** Logga misslyckade importer

## Dataflöde

```
1. Allabolag Scraper
   ↓
   [Google Sheets: Raw leads]
   ↓
2. Email Finder
   ↓
   [Google Sheets: + Email]
   ↓
3. Website Analyzer
   ↓
   [Google Sheets: + Website insights]
   ↓
4. Lead Scoring
   ↓
   [Google Sheets: + Score & Category]
   ↓
5. CRM Export (Hot & Warm)
   ↓
   [CRM: Deals created]
   ↓
6. Daily Report
   ↓
   [Telegram/Email: Notification]
```

## Felsökning

### Scraping fungerar inte
- Kontrollera att Allabolag inte har ändrat struktur
- Uppdatera HTML selectors
- Testa med andra källor

### Email hittas inte
- Prova flera email-patterns
- Använd både API och guessing
- Sök manuellt på LinkedIn

### Duplicates i CRM
- Lägg till duplicate check
- Använd organisation

snummer som unique key
- Filtrera redan exporterade leads

### Låg lead-kvalitet
- Justera sökkriterier
- Höj tröskelvärden för scoring
- Lägg till fler kvalificerings-steg

## Utveckling och förbättringar

### Framtida funktioner

1. **LinkedIn integration:** Scrapa beslutsfattare
2. **AI-powered qualification:** Använd GPT för djupare analys
3. **Sentiment analysis:** Analysera företagsnyheter
4. **Competitor tracking:** Identifiera konkurrenters kunder
5. **Lead nurturing:** Automatiska uppföljningar
6. **Performance dashboard:** Visualisera konverteringar

### Custom workflows

Skapa egna workflows för:
- Specifika branscher
- Regionala sökningar
- Event-baserad prospecting
- Referral-program

## Support

- n8n Community: https://community.n8n.io/
- Hunter.io Docs: https://hunter.io/api-documentation
- Google Sheets API: https://developers.google.com/sheets/api

Lycka till med din lead-generering!
