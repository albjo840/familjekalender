# Säljrobot - Lead-generering för Transportbolag

Automatiserad lead-generering genom web scraping och dataanalys.

## Översikt

Denna n8n-automatisering hjälper dig att hitta potentiella kunder för ditt transportbolag genom att:
- Scrapa företagsdatabaser och hemsidor
- Identifiera företag med transportbehov
- Samla kontaktinformation
- Kvalificera och poängsätta leads
- Exportera till CRM eller spara lokalt

## Workflow-komponenter

### 1. Lead Discovery (Upptäck leads)
- Scrapa företagskatalogen (allabolag.se, ratsit.se, etc.)
- Sök efter företag inom specifika branscher
- Filtrera efter storlek, omsättning, antal anställda

### 2. Lead Enrichment (Berika data)
- Hämta kontaktuppgifter (email, telefon)
- Analysera företagets hemsida
- Identifiera beslutsfattare
- Kontrollera företagsinformation

### 3. Lead Qualification (Kvalificera)
- Poängsätta leads baserat på kriterier
- Filtrera bort olämpliga företag
- Prioritera högvärdiga leads

### 4. Lead Export (Exportera)
- Spara till Google Sheets
- Exportera till CRM (Pipedrive, HubSpot)
- Skicka notifikation via Telegram/Email
- Spara lokalt som CSV

## Snabbstart

### Starta projektet

```bash
cd /home/user/n8n-automations/saljrobot
docker-compose up -d
```

### Öppna n8n

URL: http://localhost:5679

Login:
- Användarnamn: admin
- Lösenord: Se .env-filen (N8N_BASIC_AUTH_PASSWORD)

### Importera workflows

1. Öppna n8n
2. Klicka "Import from File"
3. Välj workflow från `workflows/`
4. Konfigurera credentials och API-nycklar
5. Testa workflow manuellt
6. Aktivera för automatisk körning

## Workflows

Se `workflows/README.md` för detaljerad information om varje workflow.

### Workflow 1: Allabolag Scraper
Scrapar företag från Allabolag.se baserat på sökkriterier.

### Workflow 2: Email Finder & Validator
Hittar och validerar email-adresser.

### Workflow 3: Lead Scoring & Export
Poängsätter leads och exporterar till Google Sheets/CRM.

### Workflow 4: Daily Lead Report
Daglig sammanfattning av nya leads via Telegram.

## 🎯 Era Målgrupper (Anpassade)

### Primära Branscher (Högsta potential)

**1. 🛒 E-handel** (Prioritet: Högst)
- Dagliga leveransbehov, höga volymer
- Nätbutiker, webbshopar, marketplace-säljare
- Sweet spot: 10-50 anställda, 10-50M kr omsättning

**2. 🥗 Livsmedelsföretag** (Prioritet: Högst)
- Fräschvaror, temperaturkontroll, regelbundna transporter
- Restauranger, catering, matproducenter, bagerier
- Passar: Miljö/hållbarhet-fokus, Lokala leveranser

**3. 🏭 Tillverkningsindustri** (Prioritet: Hög)
- Materialtransporter, regelbundna rutter
- Fabrikanter, producenter
- Passar: Rikstäckning (Early Bird)

**4. 🏗️ Byggföretag** (Prioritet: Hög)
- Byggmaterial, verktyg, utrustning
- Byggfirmor, entreprenörer, bygghandel
- Passar: Flexibilitet, Lokala leveranser

### Geografisk Inriktning

**Lokala Affären (SVHL):**
- 📍 **Stockholm** & omnejd
- 📍 **Väst** (Göteborg-området)
- 📍 **Halland** (Halmstad, Varberg, Falkenberg)
- 📍 **Lund/Skåne** (Malmö, Helsingborg, Landskrona)

**Early Bird (Rikstäckning):**
- 📍 Hela Sverige
- Fokus på medelstora företag med rikstäckande behov

## 📊 Lead-kvalificering (Anpassad)

**Poängsättning (0-100):**
- Omsättning 10-50M SEK: +30p (sweet spot!)
- 10-50 anställda: +20p (optimal storlek)
- E-handel eller Livsmedel: +25p (högsta prioritet)
- Tillverkning eller Bygg: +20p (hög prioritet)
- SVHL-område: +10p (lokal närvaro)
- Hemsida nämner transport/leverans: +10p
- Email validerad: +5p
- Nystartat företag (<3 år): +5p bonus

**Tröskelvärden:**
- 🔥 70-100p: Hot lead - **RING IDAG!**
- 🌡️ 50-69p: Warm lead - Ring inom 2 dagar
- ❄️ 30-49p: Cold lead - Email-kampanj
- 🧊 <30p: Very Cold - Spara till framtida kampanj

## 💡 Era Konkurrensfördelar

**Flexibilitet:** Anpassade lösningar för olika behov
**Lokala:** Närvaro i SVHL + rikstäckning
**Miljö/hållbarhet:** Attraktivt för moderna företag
**Lokal närvaro:** Personlig service och snabba leveranser

## API:er och tjänster

### Rekommenderade tjänster

1. **Företagsdata:**
   - Allabolag.se (scraping)
   - Bisnode API
   - UC API

2. **Email-sökning:**
   - Hunter.io
   - VoilaNorbert
   - Snov.io

3. **Email-validering:**
   - ZeroBounce
   - NeverBounce
   - EmailListVerify

4. **CRM:**
   - Pipedrive API
   - HubSpot API
   - Salesforce API

## Juridiskt och GDPR

### Viktiga punkter

1. **Legitimt intresse:** Du får kontakta företag för B2B-försäljning
2. **Offentlig data:** Företagsuppgifter från Bolagsverket är publika
3. **Opt-out:** Respektera företag som inte vill bli kontaktade
4. **Datalagring:** Spara endast nödvändig data
5. **Säkerhet:** Skydda kontaktuppgifter

### Best practices

- Scrapa ansvarfullt (respektera robots.txt)
- Använd rate limiting
- Validera email innan kontakt
- Erbjud enkelt sätt att avregistrera sig
- Dokumentera datakällor

## Kommandon

```bash
# Starta
docker-compose up -d

# Stoppa
docker-compose down

# Starta om
docker-compose restart

# Visa loggar
docker-compose logs -f n8n

# Uppdatera n8n
./scripts/update.sh

# Backup
./scripts/backup.sh

# Återställ
./scripts/restore.sh backups/<fil>
```

## Kataloger

- `workflows/` - n8n workflows (versionskontrollerade)
- `data/` - n8n data och databas (gitignorerad)
- `backups/` - Automatiska backups
- `scripts/` - Hjälpskript

## Konfiguration

Redigera `.env` för att ändra:
- Port (N8N_PORT)
- Autentisering (N8N_BASIC_AUTH_USER/PASSWORD)
- Databas (SQLite eller PostgreSQL)
- Webhook-URL
- Tidszon

## Support

- n8n dokumentation: https://docs.n8n.io/
- Web scraping guide: https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.htmlextract/
- HTTP Request node: https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.httprequest/

Lycka till med din lead-generering!
