# Arkitektur - n8n Automations

## Översikt

Detta system är designat för att enkelt hantera multipla n8n-instanser med Docker, där varje projekt är helt isolerat men använder samma grundmall.

## Katalogstruktur

```
n8n-automations/
├── _template/                    # Mall för nya projekt
│   ├── docker-compose.yml        # Docker-konfiguration
│   ├── .env.example              # Exempel på miljövariabler
│   ├── .gitignore                # Filignorering
│   ├── workflows/                # Standardplats för workflows
│   ├── data/                     # n8n data (gitignorerad)
│   ├── backups/                  # Backup-plats
│   └── scripts/                  # Hjälpskript
│       ├── backup.sh             # Skapar backup
│       ├── restore.sh            # Återställer från backup
│       └── update.sh             # Uppdaterar n8n
│
├── create-project.sh             # Huvudskript för att skapa projekt
├── README.md                     # Huvuddokumentation
├── QUICKSTART.md                 # Snabbstartsguide
├── ARCHITECTURE.md               # Detta dokument
├── .gitignore                    # Global gitignore
│
└── [projekt-namn]/               # Dina projekt (skapas dynamiskt)
    ├── docker-compose.yml        # Projektspecifik konfiguration
    ├── .env                      # Projektspecifika miljövariabler (gitignorerad)
    ├── README.md                 # Projektspecifik dokumentation
    ├── workflows/                # Projekts workflows
    ├── data/                     # Projekts data (gitignorerad)
    ├── backups/                  # Projekts backups
    └── scripts/                  # Projekts skript
```

## Design-principer

### 1. Isolering

Varje projekt är helt isolerat:
- **Egen Docker-container**: Ingen delning av resurser
- **Egen port**: Kan köras samtidigt utan konflikter
- **Egen databas**: SQLite eller PostgreSQL per projekt
- **Egna miljövariabler**: Unika inställningar per projekt

### 2. Repeterbarhet

Mallen gör det enkelt att skapa nya projekt:
- **Standardiserad struktur**: Alla projekt följer samma mönster
- **Automatisk konfiguration**: Skript sätter upp allt automatiskt
- **Dokumentation genereras**: Varje projekt får sin egen README

### 3. Maintainability

Enkel att underhålla och uppdatera:
- **Versionshantering**: Workflows kan versionskontrolleras
- **Backup-strategi**: Automatiska backups med rotation
- **Uppdateringar**: Enkla uppdateringsscript per projekt

### 4. Flexibilitet

Systemet är designat för att vara flexibelt:
- **Val av databas**: SQLite (standard) eller PostgreSQL
- **Anpassningsbara portar**: Stöd för multipla instanser
- **Utbyggbart**: Enkelt att lägga till fler funktioner

## Komponenter

### create-project.sh

Huvudskript som:
1. Kopierar mallen
2. Skapar `.env` från `.env.example`
3. Genererar unikt lösenord
4. Uppdaterar projektspecifika värden
5. Gör skript körbara
6. Skapar projektspecifik README

**Användning**:
```bash
./create-project.sh <projekt-namn> [port]
```

### Docker Compose

Varje projekt har sin egen `docker-compose.yml` med:
- **n8n-service**: Huvudcontainern
- **Nätverkskonfiguration**: Isolerat nätverk
- **Volumes**: Persistent lagring
- **Health checks**: Övervakning av tjänstens hälsa
- **PostgreSQL** (valfritt): Databascontainer

### Miljövariabler (.env)

Hanterar all projektkonfiguration:
- Projektnamn
- Portar
- Autentisering
- Tidszon
- Databasinställningar
- Webhook-URL
- Logging

### Backup-system

Trefaldigt backupsystem:

1. **Manuell backup** (`backup.sh`):
   - Körs på begäran
   - Sparar allt viktigt
   - Komprimerad arkivering
   - Automatisk rotation (10 senaste)

2. **Pre-restore backup**:
   - Skapar säkerhetskopia innan återställning
   - Skydd mot dataförlust

3. **Pre-update backup**:
   - Backup innan n8n-uppdatering
   - Möjlighet att rulla tillbaka

### Workflow-hantering

Workflows hanteras på två sätt:

1. **I n8n UI**: Standard användning
2. **Som filer**: Export för versionskontroll

Workflows kan:
- Exporteras från n8n
- Sparas i `workflows/`
- Versionskontrolleras med Git
- Importeras till andra projekt

## Dataflöde

### Skapa nytt projekt

```
Användare kör create-project.sh
    ↓
Kopiera _template/
    ↓
Skapa .env från .env.example
    ↓
Generera unikt lösenord
    ↓
Uppdatera projektspecifika värden
    ↓
Gör skript körbara
    ↓
Skapa projektspecifik README
    ↓
Klart!
```

### Starta projekt

```
docker-compose up -d
    ↓
Skapa container från n8nio/n8n-image
    ↓
Montera volumes (data, workflows, backups)
    ↓
Läs in .env-variabler
    ↓
Starta n8n på angiven port
    ↓
Health check verifierar att tjänsten körs
    ↓
Redo för användning!
```

### Backup-process

```
Kör backup.sh
    ↓
Skapa timestamp
    ↓
Komprimera:
  - data/
  - workflows/
  - .env
  - docker-compose.yml
    ↓
Spara i backups/
    ↓
Radera gamla backups (behåll 10 senaste)
    ↓
Klart!
```

## Säkerhet

### Autentisering

- **Basic Auth**: Aktiverad som standard
- **Unika lösenord**: Genereras per projekt
- **HTTPS**: Rekommenderas för produktion

### Data

- **Isolerad lagring**: Varje projekt har egen data
- **Gitignorerade känsliga filer**: `.env` och `data/`
- **Backup-kryptering**: Kan läggas till vid behov

### Nätverk

- **Isolerade nätverk**: Per projekt
- **Port-isolering**: Ingen delning mellan projekt
- **Firewall**: Rekommenderas för produktion

## Skalbarhet

### Vertikalt

Öka resurser per projekt:
- CPU-limits i docker-compose
- Memory-limits
- Disk space

### Horisontellt

Skapa fler projekt:
- Automatisk porttilldelning
- Obegränsat antal projekt
- Kan distribueras över flera servrar

## Underhåll

### Uppdateringar

1. **n8n-uppdateringar**: `./scripts/update.sh` per projekt
2. **Mall-uppdateringar**: Uppdatera `_template/` och skapa nya projekt
3. **System-uppdateringar**: Docker och Docker Compose

### Backup-strategi

**Rekommenderad frekvens**:
- Daglig backup för produktionsprojekt
- Veckovis för utvecklingsprojekt
- Innan större ändringar

**Lagring**:
- Lokal: `backups/` i varje projekt
- Extern: Kopiera till NAS, cloud, etc.

### Monitoring

Övervaka projekt med:
- Docker health checks
- n8n execution logs
- Disk space
- Container status

## Integration

### Med existerande system

n8n kan integreras med:
- **Familjekalendern**: Via API
- **Telegram**: Bot-notifikationer
- **Email**: SMTP för notifikationer
- **Webhooks**: Från externa tjänster
- **Databaser**: PostgreSQL, MySQL, MongoDB
- **Cloud-tjänster**: AWS, Google Cloud, Azure

### API-endpoints

Exempel på integration:
```javascript
// Hämta data från extern API
GET https://api.example.com/data

// Skicka notification via Telegram
POST https://api.telegram.org/bot<token>/sendMessage

// Spara till Google Sheets
POST https://sheets.googleapis.com/v4/spreadsheets/<id>/values
```

## Felsökning

### Vanliga problem

1. **Port redan används**
   - Lösning: Välj annan port vid skapande

2. **Container startar inte**
   - Lösning: Kolla loggar med `docker-compose logs`

3. **Data försvinner**
   - Lösning: Verifiera volumes i docker-compose.yml

4. **Webhook fungerar inte**
   - Lösning: Kontrollera WEBHOOK_URL i .env

## Framtida utveckling

Möjliga förbättringar:

1. **Automatiska backups**
   - Cron-jobb för schemalagda backups

2. **Monitoring dashboard**
   - Portainer eller custom dashboard

3. **Backup till cloud**
   - Rclone integration för cloud backup

4. **SSL/TLS automation**
   - Certbot integration för HTTPS

5. **Multi-server deployment**
   - Docker Swarm eller Kubernetes

6. **Central management**
   - Dashboard för att hantera alla projekt

## Resurser

- [n8n Dokumentation](https://docs.n8n.io/)
- [Docker Dokumentation](https://docs.docker.com/)
- [Docker Compose Referens](https://docs.docker.com/compose/)
- [n8n GitHub](https://github.com/n8n-io/n8n)
